package com.team3.rc_pro.common.paging.domain;

import java.util.List;

import com.team3.rc_pro.domain.MyReplyVO;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class MyReplyPagingCreatorDTO {
	
	private List<MyReplyVO> myreplyList ;
	private long replyTotCnt ;
	private MyReplyPagingDTO myreplyPaging ;
	
	public MyReplyPagingCreatorDTO(List<MyReplyVO> myreplyList, 
								   long replyTotCnt,
								   MyReplyPagingDTO myreplyPaging) {
		this.myreplyList = myreplyList ;
		this.replyTotCnt = replyTotCnt ;
		this.myreplyPaging = myreplyPaging ;
	}

}
