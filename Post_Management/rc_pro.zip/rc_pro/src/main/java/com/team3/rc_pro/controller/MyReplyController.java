package com.team3.rc_pro.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
//import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.team3.rc_pro.common.paging.domain.MyReplyPagingCreatorDTO;
import com.team3.rc_pro.common.paging.domain.MyReplyPagingDTO;
import com.team3.rc_pro.domain.MyReplyVO;
import com.team3.rc_pro.service.MyReplyService;



@RestController   //@Controller와는 다르게 @RestController 클래스의 메서드는 JSP 파일을 호출하지 않습니다.
@RequestMapping(value={"/replies", "/myreplies"})
public class MyReplyController {
	
	private MyReplyService myReplyService ;

	public MyReplyController(MyReplyService myReplyService) {
		this.myReplyService = myReplyService;
	}
	
	//게시물에 대한 댓글 목록 조회	GET	/replies/pages/{bno}/{pageNum}
	//브라우저 ajax 코드에서 url을 아래처럼 작성
	//http://localhost:8080/mypro00/replies/229402/page/1
	
	@GetMapping( value="/{post_id}/page/{pageNum}" ,
			     produces = {"application/json;charset=utf-8" , 
			    			 "application/xml;charset=utf-8"  }
				) //produces: 브라우저로 보내는 데이터 형식을 설정합니다.
	public ResponseEntity<MyReplyPagingCreatorDTO> 
				showReplyList(	@PathVariable("post_id") long post_id,
								@PathVariable("pageNum") Integer pageNum ){
							  //이 메서드가 호출된 URL로부터 bno 이름의 변수로 전달되는 값을 bno 매개변수에 저장
		
		MyReplyPagingCreatorDTO myreplyPagingCreator = 
				myReplyService.getReplyList(new MyReplyPagingDTO(post_id, pageNum)) ;
		
		ResponseEntity<MyReplyPagingCreatorDTO> myResponseEntity =
				new ResponseEntity<MyReplyPagingCreatorDTO>(myreplyPagingCreator, HttpStatus.OK) ;
		
		return myResponseEntity ;
	}
	
	
//게시물에 대한 댓글 등록(rno 반환) POST 		/replies/{bno}/new
	@PostMapping(value = "/{post_id}/new" , 
				 consumes = {"application/json;charset=utf-8"} ,//consumes:브라우저--> 메서드로 전송한 데이터 유형
				 produces = {"text/plain; charset=utf-8"} )		//produces:메서드--> 브라우저로 보내는 데이터 유형
	@PreAuthorize("isAuthenticated()")
	public ResponseEntity<String> registerReplyForBoard(@PathVariable("post_id") long post_id,
														@RequestBody MyReplyVO myreply) {
		Long registeredRno = myReplyService.registerReplyForBoard(myreply);
		String _registeredRno = null ;
		
		if (registeredRno != null) {
			_registeredRno = String.valueOf(registeredRno) ;
			
		} else {
			_registeredRno = String.valueOf(registeredRno) ;
		}
		
		System.out.println("_registeredRno: " + _registeredRno);
		
		return registeredRno != null ? new ResponseEntity<String>(_registeredRno, HttpStatus.OK) 
									 : new ResponseEntity<String>(_registeredRno, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
//댓글의 답글 등록(rno 반환) POST 	/replies/{bno}/new
	@PostMapping(value = "/{post_id}/{parent_reply}/new" , 
				 consumes = {"application/json;charset=utf-8"} ,//consumes:브라우저--> 메서드로 전송한 데이터 유형
				 produces = {"text/plain; charset=utf-8"} )		//produces:메서드--> 브라우저로 보내는 데이터 유형
	@PreAuthorize("isAuthenticated()")
	public ResponseEntity<String> registerReplyForReply(@PathVariable("post_id") long post_id ,
														@PathVariable("parent_reply") long parent_reply,
													    @RequestBody MyReplyVO myreply) {
	Long registeredRno = myReplyService.registerReplyForReply(myreply);
	String _registeredRno = null ;
	if (registeredRno != null) {
		_registeredRno = String.valueOf(registeredRno) ;
	} else {
		_registeredRno = String.valueOf(registeredRno) ;
	}
	
	System.out.println("_registeredRno: " + _registeredRno);
	
	return registeredRno != null ? new ResponseEntity<String>(_registeredRno, HttpStatus.OK) 
								 : new ResponseEntity<String>(_registeredRno, HttpStatus.INTERNAL_SERVER_ERROR);
}
	
//게시물에 대한 특정 댓글 조회 GET 				/replies/{bno}/{rno}
//	@GetMapping(value="/{bno}/{rno}" , 
//				produces = "application/json;charset=utf-8")
//	public ResponseEntity<MyReplyVO> showReply(@PathVariable("bno") Long bno,
//											   @PathVariable("rno") Long rno){
//
//		return new ResponseEntity<MyReplyVO>(myReplyService.getMyReply(bno, rno), HttpStatus.OK) ;
//	}
	
	@GetMapping(value="/{post_id}/{reply_id}" , 
				produces = "application/json;charset=utf-8")
	public MyReplyVO showReply(@PathVariable("post_id") Long post_id,
							   @PathVariable("reply_id") Long reply_id){

		return myReplyService.getMyReply(post_id, reply_id) ;
	}
	

//게시물에 대한 특정 댓글 수정 PUT 또는 PATCH 		/replies/{bno}/{rno}
	//Ajax에서의 요청 URI: /mypro00/replies/229402/102, PUT:PATCH
	@RequestMapping(value="/{post_id}/{reply_id}" , 
					method = {RequestMethod.PUT, RequestMethod.PATCH} ,
					consumes = "application/json;charset=utf-8" ,
					produces = "text/plain;charset=utf-8") 
	@PreAuthorize("isAuthenticated() && principal.username == #myreply.rwriter")
	public String modifyReply(@PathVariable("post_id") Long post_id,
							  @PathVariable("reply_id") Long reply_id ,
							  @RequestBody MyReplyVO myreply){
		System.out.println("컨트롤러에 전달된 myreply: " + myreply);
		
		if(myReplyService.modifyMyReply(myreply)) {
			return "modifySuccess" ;
		} else {
			return "modifyFail" ;	
		}
	}
	
	
	//특정 게시물에 대한 특정 댓글/답글 삭제(rdelFlag를 1로 업데이트)	/replies/{bno}/{rno}
	@DeleteMapping(value = "/{post_id}/{reply_id}" ,
				   consumes = "application/json; charset=utf-8",
				   produces = "text/plain;charset=utf-8")
	@PreAuthorize("isAuthenticated() && principal.username == #yourReply.rwriter")
	public ResponseEntity<String> removeReply(@PathVariable("post_id") Long post_id, 
											  @PathVariable("reply_id") Long reply_id,
											  @RequestBody MyReplyVO yourReply) {
		
		return myReplyService.modifyRdelFlag(post_id, reply_id)  
			   ? new ResponseEntity<String>("removeSuccess", HttpStatus.OK)
			   : new ResponseEntity<String>("removeFail", HttpStatus.INTERNAL_SERVER_ERROR) ;
	}
	
	
//특정 게시물에 대한 모든 댓글 삭제: 삭제 행수가 반환됨
	@DeleteMapping(value = "/{post_id}" , produces = "text/plain;charset=utf-8")
	public ResponseEntity<String> removeAllReply(@PathVariable("post_id") Long post_id){
		
		int deleteRows = myReplyService.removeAllMyReply(post_id) ;
		
		return new ResponseEntity<String>(String.valueOf(deleteRows), HttpStatus.OK) ;
	}

}
