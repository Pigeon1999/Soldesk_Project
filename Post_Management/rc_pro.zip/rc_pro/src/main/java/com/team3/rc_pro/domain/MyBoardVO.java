package com.team3.rc_pro.domain;

import java.util.Date;
import java.util.List;

import lombok.Data;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data

/*
 * bno - post_id btitle - post_title bcontent - post_content
 * bwriter(varchar) - user_num(int) 바뀜 bregDate - post_date /bmodDate - 수정날짜 사라짐
 * / breplyCnt - post_reply /bdelFlag - 삭제거부 사라짐 / bviewCnt - post_view
 * 
 * 
 */

public class MyBoardVO {
	private long post_id ;
	private String post_title ;
	private String post_content ;
	private String user_num ;
	private Date post_date ;
	private int post_view ;
	private int post_reply ;
	private int category_id;
    private int region_id;
	
	private List<MyBoardAttachFileVO> 
				attachFileList ;

}
