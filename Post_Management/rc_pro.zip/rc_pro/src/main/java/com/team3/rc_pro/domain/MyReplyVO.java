package com.team3.rc_pro.domain;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class MyReplyVO {
	
	
	
	private long reply_id ;
	private String reply_content ;
	private String rwriter ;
	private Date reply_date ;
	private long post_id ;
	private long parent_reply ;

	
	private int lvl ;  //오라클 계층쿼리의 level 값을 저장할 필드

}
