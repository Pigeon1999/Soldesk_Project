package com.team3.rc_pro.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.team3.rc_pro.domain.MyBoardAttachFileVO;
import com.team3.rc_pro.domain.MyBoardVO;
import com.team3.rc_pro.mapper.MyBoardAttachFileMapper;
import com.team3.rc_pro.mapper.MyBoardMapper;

@Service  //서비스 (구현)클래스는 DAO 또는 mapper 인터페이스의 메서드를 호출합니다.
		  //사용되는 DAO 또는 mapper 인터페이스 타입의 필드가 필요합니다.
public class MyBoardServiceImpl implements MyBoardService {
	
	private MyBoardMapper myBoardMapper ;
	private MyBoardAttachFileMapper myBoardAttachFileMapper ;
	
	//방법2: 모든 필드 초기화 생성자
	public MyBoardServiceImpl(MyBoardMapper myBoardMapper, 
							  MyBoardAttachFileMapper myBoardAttachFileMapper) {
		this.myBoardMapper = myBoardMapper;
		this.myBoardAttachFileMapper = myBoardAttachFileMapper ;
		
		//System.out.println("MyBoardServiceImpl의 모든 필드 초기화생성자입니다.");
		//System.out.println("myBoardMapper: " + myBoardMapper);
	}
	
	//위의 필드에 MyBoardMapper 인터페이스 주입
	//방법1:Setter 이용
//	public MyBoardServiceImpl() {
//		System.out.println("MyBoardServiceImpl의 기본생성자입니다.");
//	}
//	
//	@Autowired
//	public void setMyBoardMapper(MyBoardMapper myBoardMapper) {
//		this.myBoardMapper = myBoardMapper;
//		System.out.println("MyBoardServiceImpl의 MyBoardMapper의 Setter입니다.");	
//	}

	//게시물 목록 조회
//	@Override
//	public List<MyBoardVO> getBoardList(MyBoardPagingDTO myboardPaging) {
//		List<MyBoardVO> myBoardList = myBoardMapper.selectMyBoardList(myboardPaging) ;
//
//		return myBoardList;
//		//return myBoardMapper.selectMyBoardList() ;
//	}


	//게시물 등록
	@Override //저장된 게시물의 post_id 값을 반환
	@Transactional
	public long registerBoard(MyBoardVO myboard) {
		
		//System.out.println("컨트롤러 ->서비스로 전달된 myBoard: " + myBoard);
		//컨트롤러 ->서비스로 전달된 myBoard: MyBoardVO(post_id=0, btitle=서비스 새글 입력  테스트 제목, ....)
		
		//long rows = myBoardMapper.insertMyBoard(myBoard) ; 
		//System.out.println("rows: " + rows); //1
		
		//System.out.println("DB 처리 후myBoard: " + myBoard);
		//DB 처리 후myBoard: MyBoardVO(post_id=41, btitle=서비스 새글 입력  테스트 제목, ....)
		
		//return (rows == 1) ? myBoard.getpost_id() : 0;
		
		myBoardMapper.insertMyBoard(myboard) ;
		
		List<MyBoardAttachFileVO> attachFileList = myboard.getAttachFileList() ;
		
		if (attachFileList != null && attachFileList.size() > 0) {
			
			attachFileList.forEach(
					
					attachFile -> {
						attachFile.setPost_id(myboard.getPost_id()) ;
						myBoardAttachFileMapper.insertAttachFile(attachFile) ;
						
			}); //forEach-end
			
		}
		
		return myboard.getPost_id() ;
	}

	//특정 게시물 조회: 특정 게시물 하나의 데이터를 가져옴
	@Override
	@Transactional
	public MyBoardVO getBoard(long post_id, String result) {
		
		MyBoardVO myboard = myBoardMapper.selectMyBoard(post_id) ;
		
		if (result == null) {//목록페이지에서 조회요청 시에만
			myBoardMapper.updateBviewCnt(post_id) ;
		}
		
		System.out.println("myBoard: " + myboard);
		System.out.println("조회수: " + myboard.getPost_view());
		
		return myboard ; 
		
	}
	
	//특정 게시물 수정 삭제 화면 호출 
	@Override
	public MyBoardVO getBoard2(long post_id) {
		
		MyBoardVO myboard = myBoardMapper.selectMyBoard2(post_id);
		System.out.println("myBoard: " + myboard);

		return myboard ; 
		
	}

	//특정 게시물 수정
	@Override
	@Transactional
	public boolean modifyBoard(MyBoardVO myboard) {
		
		//게시물 수정
		//첨부파일 정보 수정(기존 첨부파일정보 삭제 후, 수정페이지에서 전달된 파일정보를 입력)
		
		long post_id = myboard.getPost_id();

		boolean boardModifyResult = (myBoardMapper.updateMyBoard(myboard) == 1);
		
		myBoardAttachFileMapper.deleteAttachFiles(post_id); 
		
		List<MyBoardAttachFileVO> attachFileList = myboard.getAttachFileList() ;
		
		if (boardModifyResult && attachFileList != null) {
			for(MyBoardAttachFileVO attachFile : attachFileList) {
				attachFile.setPost_id(post_id);
				myBoardAttachFileMapper.insertAttachFile(attachFile) ;	
			}
			
		}

		return boardModifyResult;
		

	}

//게시물삭제: 실제삭제(첨부파일 삭제 후, 게시물 삭제)
//실습에서만 사용(댓글이 없어야 함)
	@Transactional
	@Override
	public boolean removeBoard(long post_id) {
		
		//첨부파일 정보를 저장할 리스트 객체 생성
		List<MyBoardAttachFileVO> attachFileList = myBoardAttachFileMapper.selectAttachFiles(post_id) ;
		
		//업로드 파일 정보 삭제				
		int attachFileDeleteRows = myBoardAttachFileMapper.deleteAttachFiles(post_id);
		System.out.println("attachFileDeleteRows: " + attachFileDeleteRows);
		
		//업로드 파일 삭제
		removeAttachFiles(attachFileList);
		
		int rows = myBoardMapper.deleteMyBoard(post_id);

		return (rows == 1) ;
	}
	
//게시물삭제: 블라인드 처리	
	@Override
	@Transactional
	public boolean modifyBdelFlag(long post_id) {
		
		int rows = myBoardMapper.updateBdelFlag(post_id);

		return (rows == 1) ;
	}
	
	
	//특정 게시물의 첨부파일 목록 조회
	@Override
	public List<MyBoardAttachFileVO> getAttachFileList(Long post_id) {
		return myBoardAttachFileMapper.selectAttachFiles(post_id) ;
	}
	
	
	//톰캣 서버의 업로드 파일 삭제 메서드
	private void removeAttachFiles(List<MyBoardAttachFileVO> attachFileList) {
		
		if(attachFileList == null || attachFileList.size() == 0) {
			return ;
		}
		
		System.out.println("삭제시작: 삭제파일 목록:======\n" + attachFileList.toString());
		
//		attachFileList.forEach(
//				
//				attachFile -> {
//					//하나의 VO에 대한 실행코드를 작성, forEach 메서드가 반복함
//				}
//		);
		
		for(MyBoardAttachFileVO attachFile : attachFileList) {
			//하나의 VO에 대한 실행코드를 작성
			Path filePath = Paths.get(attachFile.getRepoPath() ,
								      attachFile.getUploadPath() ,
								      attachFile.getUuid() + "_" + attachFile.getFileName()  );
			
			boolean deleteFileResult = false ;
			
			try {
				deleteFileResult = Files.deleteIfExists(filePath) ;
				
				if(attachFile.getFileType().equals("I")) {
					Path thumbnail = Paths.get(attachFile.getRepoPath() ,
											   attachFile.getUploadPath() ,
											   "s_" + attachFile.getUuid() + "_" + attachFile.getFileName()  );
					
					Files.deleteIfExists(thumbnail) ;
							
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
		
	}

}
