package com.team3.rc_pro.mapper;

import org.apache.ibatis.annotations.Param;

import com.team3.rc_pro.domain.MyBoardVO;



public interface MyBoardMapper {


	
	//새 게시물 등록(CREATE)
	public int insertMyBoard(MyBoardVO myBoard) ;
	
	//특정 게시물 조회(detail.jsp, JOIN-SELECT): 특정 게시물 하나의 데이터를 가져옴
	public MyBoardVO selectMyBoard(long post_id) ;
	
	//특정 게시물 조회(modify:jsp, 단순-SELECT): 특정 게시물 하나의 데이터를 가져옴
	public MyBoardVO selectMyBoard2(long post_id) ;
	
	//특정 게시물 수정(UPDATE)
	public int updateMyBoard(MyBoardVO myBoard) ;
	
	//특정 게시물 삭제(DELETE)
	public int deleteMyBoard(long post_id) ;
	
	
	
	//특정 게시물 삭제요청(UPDATE)
	public int updateBdelFlag(long post_id) ;
	
	//게시물 조회수 증가(+1씩 증가)
	public int updateBviewCnt(long post_id) ;
	
	//게시물의 댓글 개수 수정: 
    //댓글추가 시에 #{amount}에 1, 댓글삭제 시 #{amount}에 -1 이 각각 전달됨
	public void updateBreplyCnt(@Param("post_id") Long post_id, @Param("amount") int amount) ;
	
	//public Date selectSysdate() ;
}
