package com.team3.rc_pro.service;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.team3.rc_pro.domain.MyBoardAttachFileVO;
import com.team3.rc_pro.domain.MyBoardVO;


@Service
@Component
public interface MyBoardService {
	
	
	//새 게시물 등록(CREATE): 
	public long registerBoard(MyBoardVO myBoard) ;
	
	//특정 게시물 조회: 특정 게시물 하나의 데이터를 가져옴(조회수1증가 고려)
	public MyBoardVO getBoard(long post_id, String result) ;
	
	//특정 게시물 수정 삭제 화면 호출 & 수정 후 조회 페이지 호출(조회수 증가 없음)
	public MyBoardVO getBoard2(long post_id) ;
	
	//특정 게시물 수정(UPDATE)
	public boolean modifyBoard(MyBoardVO myBoard) ;
	
	//특정 게시물 삭제(DELETE)
	public boolean removeBoard(long post_id) ;
	
	//특정 게시물 삭제요청(UPDATE)
	public boolean modifyBdelFlag(long post_id) ;
	
	//특정 게시물의 첨부파일 목록 조회
	public List<MyBoardAttachFileVO> getAttachFileList(Long post_id) ;
	
	//특정 게시물의 서버 업로드 파일 삭제
	//public void removeAttachFiles(List<MyBoardAttachFileVO> attachFileList) ;

}
