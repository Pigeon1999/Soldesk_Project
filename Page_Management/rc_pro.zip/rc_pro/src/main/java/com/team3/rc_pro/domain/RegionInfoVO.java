package com.team3.rc_pro.domain;

import java.sql.Timestamp;
import java.util.Date;
import lombok.Data;

public class RegionInfoVO {
	private int region_id;
	private String region_name;
}
