package com.team3.rc_pro.domain;

import java.sql.Timestamp;
import java.util.Date;
import lombok.Data;

public class CategoryInfoVO {
	private int category_id;
	private String category_name;
	private int category_authority;
}
