package com.team3.rc_pro.MapperTest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.team3.rc_pro.mapper.BoardListMapper;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/mybatis-context.xml")
@Log4j
public class BoardMapperTest {

//	@Setter(onMethod_ = @Autowired)
//	private BoardListMapper boardListMapper ;

	private BoardListMapper boardListMapper ;

	@Autowired
	public void setBoardMapper(BoardListMapper boardListMapper) {
		this.boardListMapper = boardListMapper ;
	}

//  //게시물 목록 조회 테스트 <-- 테스트 후 메서드 주석처리
//  @Test
//  public void testSelectBoardList() {
//	  boardListMapper.selectBoardList().forEach(board -> log.info(board));
//  }

//	//게시물 목록 조회 테스트 <-- 테스트 후 메서드 주석처리
//	  @Test
//	  public void testSelectBoardListWithPaging() {
//
//	      BoardPagingDTO boardPagingDTO = new BoardPagingDTO();//기본 생성자 이용
//
//	      boardListMapper.selectBoardList(boardPagingDTO)
//	                   .forEach(board -> System.out.println(board));
//
//	      boardPagingDTO = new BoardPagingDTO(2, 1, 1, 10);
//	      boardListMapper.selectBoardList(boardPagingDTO)
//	                   .forEach(board -> System.out.println(board));
//	  }

	//게시물 목록 조회 테스트 - 검색 기능
//    @Test
//    public void testSearchBoardWithPaging() {
//        BoardPagingDTO boardPagingDTO = new BoardPagingDTO(); //기본 생성자 이용(1, 1, 1, 10)
//        boardPagingDTO.setKeyword("제목");
//
//        //boardPagingDTO.setScope("T");
//        //boardPagingDTO.setScope("C");
//        //boardPagingDTO.setScope("W");
//        //boardPagingDTO.setScope("TC");
//        boardPagingDTO.setScope("TCW");
//        //boardPagingDTO.setScope("TW");
//        //boardPagingDTO.setScope("CW");
//        log.info("행 총 개수: " + boardListMapper.selectRowTotal(boardPagingDTO));
//
//        List<BoardVO> list = boardListMapper.selectBoardList(boardPagingDTO);
//        list.forEach(board -> log.info(board));
//    }

//	//게시물 목록 조회 테스트 - 검색 기능 날짜 포함
//    @Test
//    public void testSearchBoardWithPagingDate() {
//        BoardPagingDTO boardPagingDTO = new BoardPagingDTO(); //기본 생성자 이용(1, 1, 1, 10)
//        boardPagingDTO.setKeyword("제목");
//
//        //boardPagingDTO.setScope("T");
//        //boardPagingDTO.setScope("C");
//        //boardPagingDTO.setScope("W");
//        //boardPagingDTO.setScope("TC");
//        boardPagingDTO.setScope("TCW");
//        //boardPagingDTO.setScope("TW");
//        //boardPagingDTO.setScope("CW");
//
//        //boardPagingDTO.setScope("CW");
//
//        boardPagingDTO.setBeginDate("2024-01-12");
//        boardPagingDTO.setEndDate("2024-01-12");
//
//        log.info("행 총 개수: " + boardListMapper.selectRowTotal(boardPagingDTO));
//
//        List<BoardVO> list = boardListMapper.selectBoardList(boardPagingDTO);
//        list.forEach(board -> log.info(board));
//    }

	//	@Test
	//	public void testSelectSysdate() {
	//
	//		log.info(boardMapper.selectSysdate()) ;
	//	}
}
