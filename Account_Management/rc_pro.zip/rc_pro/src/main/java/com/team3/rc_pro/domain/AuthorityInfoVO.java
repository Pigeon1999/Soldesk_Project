package com.team3.rc_pro.domain;

import lombok.Data;

@Data
public class AuthorityInfoVO {

	private int user_num;
	private String user_authority;
	
}
