package com.team3.rc_pro.domain;

import lombok.Data;

@Data
public class CategoryInfoVO {
	private int category_id;
	private String category_name;
	private int category_authority;
}
