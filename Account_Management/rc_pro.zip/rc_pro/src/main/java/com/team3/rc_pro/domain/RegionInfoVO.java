package com.team3.rc_pro.domain;

import lombok.Data;

@Data
public class RegionInfoVO {
	private int region_id;
	private String region_name;
}
