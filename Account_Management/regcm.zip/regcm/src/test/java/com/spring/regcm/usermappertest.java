package com.spring.regcm;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.spring.regcm.domain.userVO;
import com.spring.regcm.domain.userVO;
import com.spring.regcm.mapper.usermapper;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/mybatis-context.xml")
@Log4j
public class usermappertest {

	@Autowired
	private usermapper usermapper;
	
	@Test
	public void userregister() {
		userVO myuser = new userVO();
		
//		myuser.setUsernum(1);
		myuser.setUser_name("김동현");
		myuser.setUser_birth("970627");
		myuser.setUser_pn("010-7173-3649");
		myuser.setUser_address("관철동");
		myuser.setUser_email("kimdonghyun481@gmail.com");
		myuser.setUser_id("kimdonghyun80");
		myuser.setUser_passwd("12312aS!");
		
		usermapper.insertuserinfo(myuser);
	}
}
