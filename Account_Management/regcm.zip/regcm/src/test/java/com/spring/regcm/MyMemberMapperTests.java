package com.spring.regcm;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.spring.regcm.domain.userVO;
import com.spring.regcm.mapper.usermapper;

import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration      //폴더 구분자로 \\ 사용 시 오류 발생. /를 사용하세요.
@ContextConfiguration({"file:src/main/webapp/WEB-INF/spring/mybatis-context.xml" ,
                       "file:src/main/webapp/WEB-INF/spring/security-context.xml" ,
                       "file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"})
@Log4j
@NoArgsConstructor
public class MyMemberMapperTests {

    //사용자 패스워드 암호화 
    @Setter(onMethod_ = @Autowired)
    private PasswordEncoder pwencoder;
    
    @Setter(onMethod_ = @Autowired)
    private usermapper usermapper;

    //회원 등록 테스트: 테스트(1)
//    @Test
//    public void testInsertMyMember() {
//    	
//        userVO member = new userVO();
//        
//        for(int i = 10; i < 100; i++) {
//
//        	member.setUser_passwd(pwencoder .encode("pw" + i));
//        	member.setUser_birth("0101" + i);
//        	member.setUser_email("email" + i + "@gmail.com");
//        	member.setUser_pn("010-1234-23" + i);
//        	member.setUser_address("관철동");
//            if(i <= 70) {
//            	member.setUser_id("user" + i);
//            	member.setUser_name("일반사용자" + i);
//            } else if (i <= 80) {
//            	member.setUser_id("member" + i);
//            	member.setUser_name("중급사용자" + i);
//            } else if (i <= 90) {
//            	member.setUser_id("manager" + i);
//            	member.setUser_name("운영자" + i);
//                
//            } else {
//            	member.setUser_id("admin" + i);
//            	member.setUser_name("관리자" + i);
//            }           
//            usermapper.insertuserinfo(member);
//        } //for-End
//    }
    
    //회원 권한 등록 테스트: 테스트(2)
//    @Test
//    public void testInsertMyMemAuthority() {
//		
//        userAuthorityVO myAuthority = new userAuthorityVO();
//        
//        for(int i = 10; i < 100; i++) {
//
//            if(i <= 70) {
//                myAuthority.setUser_id("user" +i);
//                myAuthority.setUser_authority("ROLE_USER");
//            } else if (i <= 80) {
//                myAuthority.setUser_id("member" +i);
//                myAuthority.setUser_authority("ROLE_MEMBER");
//            }else if (i <= 90) {
//                myAuthority.setUser_id("manager" +i);
//                myAuthority.setUser_authority("ROLE_MANAGER");
//            } else {
//                myAuthority.setUser_id("admin" +i);
//                myAuthority.setUser_authority("ADMIN");
//            }
//            log.info(myAuthority);
//            usermapper.insertuserauthority(myAuthority) ;
//        } //for-End
//        
//        myAuthority.setUser_id("admin99");
//        myAuthority.setUser_authority("ROLE_MANAGER");
//        usermapper.insertuserauthority(myAuthority);
//        
//        myAuthority.setUser_id("admin99");
//        myAuthority.setUser_authority("ROLE_MEMBER");
//        usermapper.insertuserauthority(myAuthority);
//        
//        myAuthority.setUser_id("admin91");
//        myAuthority.setUser_authority("ROLE_MANAGER");
//        usermapper.insertuserauthority(myAuthority);
//    }
//    
    //회원 정보 조회 테스트: 테스트(3) 
    @Test
    public void testRead() {
        userVO user = usermapper.viewuserinfo("admin99");
        log.info(user);
        
        user.getAuthorityList().forEach(authority -> log.info(authority));
    }

} //class-end

