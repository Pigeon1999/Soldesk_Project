package com.spring.regcm.service;

import com.spring.regcm.domain.userVO;

public interface userservice {

	//회원 등록
	public boolean registeruser(userVO userVO);
	
	//아이디 중복체크
	public Long checkuserid(String user_id);

	
}
