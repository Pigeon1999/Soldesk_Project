package com.spring.regcm.common.security;

import java.util.stream.Collectors;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

import com.spring.regcm.domain.userVO;

import lombok.Getter;

@Getter
public class myuser extends User{
	private static final long serialVersionUID = 1L ;
	private userVO user;
	 
	public myuser(userVO user) {
		 
		 super(user.getUser_id(),
			   user.getUser_passwd(),
			   user.getAuthorityList()
			   .stream()
			   .map(auth -> new SimpleGrantedAuthority(auth.getUser_authority()))
			   .collect(Collectors.toList())
	);
	System.out.println("myuser 생성자에 전달된 userVO 정보:" + user.toString());
	this.user = user ;
	}
}
