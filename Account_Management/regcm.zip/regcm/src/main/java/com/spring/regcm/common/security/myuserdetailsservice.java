package com.spring.regcm.common.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.spring.regcm.domain.userVO;
import com.spring.regcm.mapper.usermapper;

public class myuserdetailsservice implements UserDetailsService{

	private usermapper usermapper;
	
	@Autowired
	public void setusermapper(usermapper usermapper) {
		this.usermapper = usermapper;
	}
	
	@Override
	public UserDetails loadUserByUsername(String user_id) throws UsernameNotFoundException {
		
		userVO user = usermapper.viewuserinfo(user_id);
		UserDetails userdetail = new myuser(user); 
		System.out.println("userdetail: " + userdetail.toString());
		return user == null ? null : userdetail;
	} 
	
}
