package com.spring.regcm.domain;

import java.sql.Timestamp;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Data
public class userVO {
	private Long user_num ;
	private String user_name;
	private String user_birth ;
	private String user_pn;
	private String user_address;
	private String user_email;
	private String user_id ;
	private String user_passwd ;
	private Timestamp user_regDate ;
	
	private List<userAuthorityVO> authorityList;
	
}
