package com.spring.regcm.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.regcm.domain.userAuthorityVO;
import com.spring.regcm.domain.userVO;
import com.spring.regcm.mapper.usermapper;

@Service
public class userserviceImpl implements userservice {
	
	private usermapper usermapper;
	private PasswordEncoder pwencoder;
	
	public userserviceImpl(usermapper userMapper,PasswordEncoder pwencoder) {
		this.usermapper = userMapper;
		this.pwencoder = pwencoder;
	}

	@Override
	@Transactional
	public Long checkuserid(String userid) {
		return usermapper.iddupcheck(userid);
	}
	
	@Override
	@Transactional
	public boolean registeruser(userVO userVO) {
		
		userVO.setUser_passwd(pwencoder.encode(userVO.getUser_passwd()));
		usermapper.insertuserinfo(userVO);
		usermapper.insertuserauthority(userVO.getUser_id());
		return true;
	}
	
	
	
}
