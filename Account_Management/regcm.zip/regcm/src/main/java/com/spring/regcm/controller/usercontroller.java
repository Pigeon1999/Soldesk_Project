package com.spring.regcm.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.regcm.domain.userVO;
import com.spring.regcm.service.userservice;

@Controller
@RequestMapping("/")
public class usercontroller {

//	@Setter(onMethod_ = @Autowired )
	private userservice userservice;
	
	public usercontroller(userservice userservice) {
		this.userservice = userservice;
		System.out.println("userservice의 모든 필드 초기화 생성자입니다.");
	}
	

	//회원가입페이지
	@GetMapping("/register")
	public String userregisterpage() {
		System.out.println("회원가입 페이지 호출");
		return "myboard/register";
	}
	
	@GetMapping("/home")
	public String hometest() {
		System.out.println("홈페이지 호출");
		return "myboard/home";
	}
	
	@GetMapping("/home_member")
	public String home_membertest() {
		System.out.println("홈페이지 호출");
		return "myboard/home_member";
	}
	
	@GetMapping("/home_admin")
	public String home_damintest() {
		System.out.println("홈페이지 호출");
		return "myboard/home_admin";
	}
	
	//회원가입
	@PostMapping("/register")
	public ResponseEntity<String> userreiger(userVO userVO,RedirectAttributes redirectAttr) {
		System.out.println("회원가입페이지 post");
		System.out.println(userVO);
		boolean signupresult = userservice.registeruser(userVO);
		
		if(signupresult) { 
			redirectAttr.addAttribute("result","successsign"); 
		}else {
			redirectAttr.addAttribute("result","failsign"); 
		}
		String result = String.valueOf(signupresult);
		System.out.println("회원가입 완료");
		return new ResponseEntity<>(result,HttpStatus.OK);
	}
	
	//아이디 중복체크
	@ResponseBody
	@PostMapping("/iddupcheck")
	public ResponseEntity<Long> userregister(String user_id) {
		Long result = userservice.checkuserid(user_id);
		System.out.println("아이디 중복체크기능 입력된아이디: " + user_id);
		return new ResponseEntity<>(result,HttpStatus.OK);
	}
}
