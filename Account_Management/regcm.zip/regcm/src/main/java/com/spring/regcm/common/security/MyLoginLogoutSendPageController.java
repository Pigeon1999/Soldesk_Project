package com.spring.regcm.common.security;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MyLoginLogoutSendPageController {
	
	@GetMapping("/login")
	public String sendLoginPage (String error, String logout, Model model) {
		
		if (error != null) {
			System.out.println("=========:error.length(): " + error.length()); 
			System.out.println("=========:error.hashCode(): " + error.hashCode());
			model.addAttribute("error", "아이디혹은 비밀번호를 확인하세요.") ;
		
		} else if(logout != null) {
			model.addAttribute("logout", "로그아웃 되었습니다.") ;	
		} else {
			model.addAttribute("normal", "사용자가 로그인 페이지 호출") ;
		}
		return "myboard/login" ;
	}

}
