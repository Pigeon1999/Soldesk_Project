package com.spring.regcm.mapper;

import com.spring.regcm.domain.userVO;

public interface usermapper {

	//회원 등록
	public void insertuserinfo(userVO myuser);
	
	//회원 권한 추가
	public void insertuserauthority(String user_id);
	
	//아이디 중복체크기능
	public Long iddupcheck(String user_id);
	
	//회원 조회
	public userVO viewuserinfo(String user_id);

}
