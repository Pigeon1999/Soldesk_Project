package com.spring.regcm.domain;

import lombok.Data;

@Data
public class userAuthorityVO {

	private String user_id;
	private String user_authority;

}
